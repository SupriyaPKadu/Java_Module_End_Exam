package vehicle_exception;

public class InvalidVehicleException {

	public InvalidVehicleException(String msg) {
		super();
	   
	}
   
	
}
